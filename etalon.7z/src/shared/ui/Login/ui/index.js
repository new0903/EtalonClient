import { Link } from "react-router-dom";
import { StoreService } from "../../../lib/services/storeService";

export const Login = ({ extraClasses = [], extraAttrs = [] } = {}) => {
  return (
    <div className={"login-form " + extraClasses.join(" ")}>
      
    </div>
  );
};
