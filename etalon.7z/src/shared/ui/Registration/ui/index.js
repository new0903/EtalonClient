import { Link } from "react-router-dom";
import { StoreService } from "../../../lib/services/storeService";

export const NavigationBar = ({ extraClasses = [], extraAttrs = [] } = {}) => {
  return (
    <div className={"Reg-form " + extraClasses.join(" ")}>
      
    </div>
  );
};
