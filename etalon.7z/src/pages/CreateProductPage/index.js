export { CreateProductPage } from "./ui/index.js";
