export { RegisterUserPage } from "./ui/index.js";
