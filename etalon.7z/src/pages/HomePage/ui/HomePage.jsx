import { NavigationBar } from "../../../shared/ui/NavigationBar/index";
import { AuthorizationPage } from "../../AuthorizationPage/ui/AuthorizationPage.jsx";  


export const HomePage = ({ extraClasses = [], extraAttrs = [] } = {}) => {
  // const store = new StoreService("activePanel");

  return (
    // <NavigationBar />
    <AuthorizationPage />
      
  );
}
